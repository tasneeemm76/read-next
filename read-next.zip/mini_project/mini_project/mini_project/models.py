from django.db import models

class CustomerDetails(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=15)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    class Meta:
        db_table = "customerDetails"

from django.db import models

class Book(models.Model):
    bookID = models.AutoField(primary_key=True)  # Add this line
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField(blank=True)  # Allow blank description
    publication_date = models.DateField()
    image = models.ImageField(upload_to='book_images/', blank=True, null=True)
    class Meta:
        db_table = 'mini_project_book'

class Review(models.Model):
    review_id = models.AutoField(primary_key=True)
    customer_name = models.CharField(max_length=50)
    bookID = models.IntegerField(default=0)  
    comment = models.TextField()

    class Meta:
        db_table = 'Reviews'
from .forms import CustomerDetailsForm
from django.shortcuts import render, redirect
from .models import Book
from .models import CustomerDetails
from .forms import BookForm
from django.shortcuts import render, get_object_or_404
from .forms import ReviewForm


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Check if username and password combination exists in the database
        if CustomerDetails.objects.filter(username=username, password=password).exists():
            # Pass the username to the index page
            return redirect('index_with_username', username=username)
        else:
            # Redirect to sign-in page if login credentials are invalid
            return redirect('signup')
    
    # Render the login form template for GET requests
    return render(request, 'login.html')

def index(request, username):
    return render(request, 'index.html', {'username': username})


def search_view(request):
    if request.method == 'POST':
        search_query = request.POST.get('search_query', '')
        search_results = Book.objects.filter(title__icontains=search_query)
        return render(request, 'search_results.html', {'search_results': search_results, 'search_query': search_query})
    else:
        return render(request, 'search_results.html')



def display(request):
            return render(request, 'book_details.html')

   
def customer_details(request):
    if request.method == 'POST':
        form = CustomerDetailsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to the 'index' URL pattern
    else:
        form = CustomerDetailsForm()
    return render(request, 'customer_details.html', {'form': form})


from django.shortcuts import render, redirect
from .forms import BookForm

def create_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)  # Include request.FILES for handling files
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = BookForm()
    return render(request, 'create_book.html', {'form': form})

def book_list(request):
    books = Book.objects.all()
    username = request.GET.get('username')
    
    return render(request, 'book_list.html', {'books': books, 'username': username})






from django.shortcuts import render, get_object_or_404
from .models import Book

def book_details(request, book_id):
    # Retrieve the book object from the database using the book ID
    book = get_object_or_404(Book, bookID=book_id)
    return render(request, 'book_details.html', {'book': book})

def add_review(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            form.save()
            # After saving the review, redirect to a success page or the book details page
            return redirect('book_details')  # Adjust the URL name as per your project
    else:
        form = ReviewForm()

    return render(request, 'index.html', {'form': form})

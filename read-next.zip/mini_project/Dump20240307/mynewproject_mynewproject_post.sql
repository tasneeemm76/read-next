-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mynewproject
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mynewproject_post`
--

DROP TABLE IF EXISTS `mynewproject_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mynewproject_post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `caption` longtext NOT NULL,
  `image_url` varchar(200) NOT NULL,
  `user_id` bigint NOT NULL,
  `likes` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `myNewProject_post_user_id_0f44af8b_fk_myNewProject_user_id` (`user_id`),
  CONSTRAINT `myNewProject_post_user_id_0f44af8b_fk_myNewProject_user_id` FOREIGN KEY (`user_id`) REFERENCES `mynewproject_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mynewproject_post`
--

LOCK TABLES `mynewproject_post` WRITE;
/*!40000 ALTER TABLE `mynewproject_post` DISABLE KEYS */;
INSERT INTO `mynewproject_post` VALUES (16,'hi','\"C:\\Users\\Tasneem\\myNewProject\\cake.jpg\"',3,0),(17,'IMAGE TRIAL','\"C:\\Users\\Tasneem\\myNewProject\\media\\images\\cake.jpg\"',7,0),(18,'IMAGE TRIAL','\"C:\\Users\\Tasneem\\myNewProject\\media\\images\\cake.jpg\"',7,0),(19,'MY NAME IS TASNEEM','CAKE',6,0),(20,'YOOOOOOOOOOOOO','\"\\cake.jpg\"',7,0),(25,'NEWWWWWWW POSTTTTTTTTTTT','\"C:\\Users\\Tasneem\\myNewProject\\static\\pancake.jpg\"',7,0),(26,'NEWWWWWWW POSTTTTTTTTTTT','pancake.jpg',7,0),(28,'TRIAL','IMAGEEEEEEEE',7,0),(30,'GOOD MORNINGGGG!!!','SUNSHINE',6,0),(31,'THIS IS MY DJANGO PROJECT','xyz',9,0),(32,'ANOTHER TRIAL POST','\"C:\\Users\\Tasneem\\myNewProject\\media\\images\\cake.jpg\"',10,0),(33,'CAPTION','IMAGEEEEEEEE',7,0),(35,'AVNEEEEETTTTTTTTTT SETHIIIIIIIIIII','IMAGEEEEEE',6,0),(36,'xcvbnm','IMAGEEEEEEEE',7,0);
/*!40000 ALTER TABLE `mynewproject_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-07 12:43:14
